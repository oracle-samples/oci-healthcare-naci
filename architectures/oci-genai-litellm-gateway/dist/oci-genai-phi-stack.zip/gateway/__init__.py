"""OCI GenAI reference gateway."""
